This website is intended to convey information about Japan's train systems.

It was created for AS91893.

Enjoy.
